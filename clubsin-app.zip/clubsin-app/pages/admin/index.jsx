import { useState, useEffect } from 'react'
import { supabase } from '../../lib/supabase'
import { useAuth } from '../../hooks/useAuth'
import toast from 'react-hot-toast'
import {
  LayoutDashboard, Users, Settings, Shield, Clock,
  CheckCircle, XCircle, Key, AlertTriangle, Save
} from 'lucide-react'

export default function Admin() {
  const { profile, isAdmin, isManager } = useAuth()
  const [activeTab, setActiveTab] = useState('dashboard')
  const [pendingActivities, setPendingActivities] = useState([])
  const [members, setMembers] = useState([])
  const [settings, setSettings] = useState({})
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')
  const [showModal, setShowModal] = useState(null)
  const [selectedMember, setSelectedMember] = useState(null)
  const [tempPassword, setTempPassword] = useState(null)

  useEffect(() => {
    if (!isAdmin && !isManager) return
    fetchAllData()
  }, [isAdmin, isManager])

  async function fetchAllData() {
    setLoading(true)
    await Promise.all([fetchPending(), fetchMembers(), fetchSettings()])
    setLoading(false)
  }

  async function fetchPending() {
    const { data } = await supabase
      .from('activities')
      .select(`*, profiles(id, full_name, email, company), activity_types(name, default_points)`)
      .eq('status', 'pending')
      .order('created_at', { ascending: false })
    setPendingActivities(data || [])
  }

  async function fetchMembers() {
    const { data } = await supabase
      .from('profiles')
      .select(`*, syndic_categories(name)`)
      .eq('association_id', 'a1b2c3d4-e5f6-7890-abcd-ef1234567890')
      .order('full_name')
    setMembers(data || [])
  }

  async function fetchSettings() {
    const { data } = await supabase
      .from('system_settings')
      .select('*')
      .eq('association_id', 'a1b2c3d4-e5f6-7890-abcd-ef1234567890')
    const map = {}
    data?.forEach(s => { map[s.setting_key] = s })
    setSettings(map)
  }

  async function approveActivity(activityId) {
    try {
      const { error } = await supabase.rpc('approve_activity', {
        p_activity_id: activityId,
        p_admin_id: profile.id
      })
      if (error) throw error
      toast.success('Atividade aprovada!')
      fetchPending()
    } catch (err) { toast.error(err.message) }
  }

  async function rejectActivity(activityId, reason) {
    try {
      const { error } = await supabase.rpc('reject_activity', {
        p_activity_id: activityId,
        p_admin_id: profile.id,
        p_reason: reason
      })
      if (error) throw error
      toast.success('Atividade rejeitada')
      fetchPending()
    } catch (err) { toast.error(err.message) }
  }

  async function generatePassword(memberId) {
    try {
      const { error } = await supabase.rpc('generate_temporary_password', {
        p_profile_id: memberId,
        p_admin_id: profile.id
      })
      if (error) throw error
      setTempPassword('A3B7-C9D2-E1F8')
      setShowModal('showPassword')
      toast.success('Senha temporária gerada!')
      fetchMembers()
    } catch (err) { toast.error(err.message) }
  }

  async function unlockAccount(memberId) {
    try {
      const { error } = await supabase.rpc('unlock_account', {
        p_profile_id: memberId,
        p_admin_id: profile.id
      })
      if (error) throw error
      toast.success('Conta desbloqueada!')
      fetchMembers()
    } catch (err) { toast.error(err.message) }
  }

  async function updateSetting(key, value) {
    try {
      const { error } = await supabase.rpc('update_system_setting', {
        p_setting_key: key,
        p_setting_value: String(value),
        p_admin_id: profile.id
      })
      if (error) throw error
      toast.success('Configuração atualizada!')
      fetchSettings()
    } catch (err) { toast.error(err.message) }
  }

  if (!isAdmin && !isManager) {
    return (
      <div style={{ textAlign: 'center', padding: '60px 20px' }}>
        <Shield size={48} style={{ color: '#dc2626', marginBottom: 16 }} />
        <h2 style={{ fontSize: 20, fontWeight: 700 }}>Acesso Negado</h2>
        <p style={{ color: '#94a3b8', marginTop: 8 }}>Você não tem permissão para acessar esta área.</p>
      </div>
    )
  }

  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'pending', label: 'Pendentes', icon: Clock, badge: pendingActivities.length },
    { id: 'members', label: 'Associados', icon: Users },
    { id: 'security', label: 'Segurança', icon: Shield },
  ]

  const inputStyle = {
    padding: '6px 12px', border: '1px solid #e2e8f0',
    borderRadius: 8, fontSize: 13, outline: 'none'
  }

  return (
    <div style={{ display: 'flex', minHeight: '100vh', background: '#f8fafc' }}>
      {/* Sidebar */}
      <aside style={{ width: 220, background: '#fff', borderRight: '1px solid #e2e8f0', display: 'flex', flexDirection: 'column', padding: '20px 0' }}>
        <div style={{ padding: '0 16px 16px', borderBottom: '1px solid #e2e8f0', marginBottom: 12 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <div style={{ width: 32, height: 32, borderRadius: 8, background: 'linear-gradient(135deg, #2d8f5a, #1a5c3a)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'white', fontSize: 14, fontWeight: 700 }}>C</div>
            <div>
              <div style={{ fontSize: 13, fontWeight: 700, color: '#1e293b' }}>Clubsin Ceará</div>
              <div style={{ fontSize: 10, color: '#94a3b8' }}>Administração</div>
            </div>
          </div>
        </div>
        <nav style={{ flex: 1, padding: '0 10px' }}>
          {menuItems.map((item) => {
            const Icon = item.icon
            return (
              <button key={item.id} onClick={() => setActiveTab(item.id)}
                style={{ width: '100%', display: 'flex', alignItems: 'center', gap: 8, padding: '8px 12px', borderRadius: 8, marginBottom: 2, fontSize: 13, fontWeight: activeTab === item.id ? 600 : 500, color: activeTab === item.id ? '#1a5c3a' : '#64748b', background: activeTab === item.id ? '#e8f5ee' : 'transparent', border: 'none', cursor: 'pointer', textAlign: 'left' }}>
                <Icon size={16} /> {item.label}
                {item.badge > 0 && <span style={{ marginLeft: 'auto', background: '#dc2626', color: 'white', fontSize: 10, fontWeight: 700, padding: '1px 6px', borderRadius: 10 }}>{item.badge}</span>}
              </button>
            )
          })}
        </nav>
        <div style={{ padding: '12px 16px 0', borderTop: '1px solid #e2e8f0' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 12, color: '#94a3b8' }}>
            <div style={{ width: 28, height: 28, borderRadius: '50%', background: '#1a5c3a', color: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 11, fontWeight: 700 }}>AD</div>
            <span>{profile?.full_name || 'Admin'}</span>
          </div>
        </div>
      </aside>

      {/* Main */}
      <main style={{ flex: 1, padding: '24px 28px', overflow: 'auto' }}>
        {loading ? <p style={{ color: '#94a3b8' }}>Carregando...</p> : (
          <>
            {/* DASHBOARD */}
            {activeTab === 'dashboard' && (
              <div>
                <div style={{ marginBottom: 20 }}>
                  <h1 style={{ fontSize: 18, fontWeight: 700, color: '#1e293b' }}>Dashboard</h1>
                  <p style={{ fontSize: 12, color: '#94a3b8' }}>Visão geral da gamificação · Temporada 2026</p>
                </div>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12, marginBottom: 20 }}>
                  {[
                    { label: 'Associados Ativos', value: members.filter(m => m.status === 'active').length, color: '#3b82f6' },
                    { label: 'Contas Bloqueadas', value: members.filter(m => m.status === 'suspended').length, color: '#dc2626' },
                    { label: 'Atividades Pendentes', value: pendingActivities.length, color: '#f59e0b' },
                    { label: 'Total de Pontos', value: '4.287', color: '#16a34a' },
                  ].map((stat, i) => (
                    <div key={i} style={{ background: '#fff', border: '1px solid #e2e8f0', borderRadius: 10, padding: 14 }}>
                      <div style={{ fontSize: 11, color: '#94a3b8', fontWeight: 500, marginBottom: 6 }}>{stat.label}</div>
                      <div style={{ fontSize: 22, fontWeight: 700, color: stat.color }}>{stat.value}</div>
                    </div>
                  ))}
                </div>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12 }}>
                  {[
                    { title: '⏳ Aprovar Atividades', desc: `${pendingActivities.length} atividades aguardando`, tab: 'pending' },
                    { title: '🔒 Segurança', desc: 'Configure tentativas e bloqueios', tab: 'security' },
                    { title: '👥 Gerenciar Associados', desc: `${members.length} associados`, tab: 'members' },
                  ].map((card, i) => (
                    <div key={i} onClick={() => setActiveTab(card.tab)} style={{ background: '#fff', border: '1px solid #e2e8f0', borderRadius: 10, padding: 16, cursor: 'pointer' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
                        <span style={{ fontSize: 14, fontWeight: 700 }}>{card.title}</span>
                        <span style={{ fontSize: 18 }}>→</span>
                      </div>
                      <div style={{ fontSize: 12, color: '#94a3b8' }}>{card.desc}</div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* PENDING */}
            {activeTab === 'pending' && (
              <div>
                <div style={{ marginBottom: 16 }}>
                  <h1 style={{ fontSize: 18, fontWeight: 700 }}>Atividades Pendentes</h1>
                  <p style={{ fontSize: 12, color: '#94a3b8' }}>{pendingActivities.length} atividades aguardando aprovação</p>
                </div>
                <div style={{ background: '#fff', border: '1px solid #e2e8f0', borderRadius: 12, overflow: 'hidden' }}>
                  <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                    <thead><tr style={{ background: '#f8fafc' }}>
                      {['Associado', 'Tipo', 'Descrição', 'Pontos', 'Ações'].map(h => (
                        <th key={h} style={{ padding: '10px 12px', fontSize: 11, fontWeight: 600, textTransform: 'uppercase', color: '#94a3b8', textAlign: 'left' }}>{h}</th>
                      ))}
                    </tr></thead>
                    <tbody>
                      {pendingActivities.map((act) => (
                        <tr key={act.id} style={{ borderBottom: '1px solid #f1f5f9' }}>
                          <td style={{ padding: '10px 12px' }}>
                            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                              <div style={{ width: 28, height: 28, borderRadius: '50%', background: '#f1f5f9', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 10, fontWeight: 700, color: '#64748b' }}>
                                {act.profiles?.full_name?.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase()}
                              </div>
                              <div>
                                <div style={{ fontSize: 13, fontWeight: 600 }}>{act.profiles?.full_name}</div>
                                <div style={{ fontSize: 11, color: '#94a3b8' }}>{act.profiles?.company}</div>
                              </div>
                            </div>
                          </td>
                          <td style={{ padding: '10px 12px' }}>
                            <span style={{ padding: '2px 8px', borderRadius: 12, fontSize: 11, fontWeight: 600, background: '#fef3c7', color: '#b45309' }}>{act.activity_types?.name}</span>
                          </td>
                          <td style={{ padding: '10px 12px', fontSize: 13 }}>{act.title}</td>
                          <td style={{ padding: '10px 12px', fontSize: 14, fontWeight: 700, color: '#1a5c3a' }}>+{act.activity_types?.default_points * (act.quantity || 1)}</td>
                          <td style={{ padding: '10px 12px' }}>
                            <div style={{ display: 'flex', gap: 4 }}>
                              <button onClick={() => approveActivity(act.id)} style={{ padding: '4px 10px', fontSize: 11, fontWeight: 600, borderRadius: 5, border: 'none', cursor: 'pointer', background: '#dcfce7', color: '#166534' }}>✓ Aprovar</button>
                              <button onClick={() => { setSelectedMember(act); setShowModal('reject') }} style={{ padding: '4px 10px', fontSize: 11, fontWeight: 600, borderRadius: 5, border: 'none', cursor: 'pointer', background: '#fee2e2', color: '#991b1b' }}>✕ Rejeitar</button>
                            </div>
                          </td>
                        </tr>
                      ))}
                      {pendingActivities.length === 0 && (
                        <tr><td colSpan={5} style={{ padding: 20, textAlign: 'center', color: '#94a3b8' }}>Nenhuma atividade pendente 🎉</td></tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* MEMBERS */}
            {activeTab === 'members' && (
              <div>
                <div style={{ marginBottom: 16 }}>
                  <h1 style={{ fontSize: 18, fontWeight: 700 }}>Associados</h1>
                  <p style={{ fontSize: 12, color: '#94a3b8' }}>{members.length} associados cadastrados</p>
                </div>
                <div style={{ marginBottom: 12, display: 'flex', gap: 8 }}>
                  <input type="text" placeholder="🔍 Buscar..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} style={{ ...inputStyle, minWidth: 280 }} />
                  <select style={inputStyle}><option>Todas as categorias</option><option>Síndico I</option><option>Síndico II</option><option>Síndico III</option></select>
                </div>
                <div style={{ background: '#fff', border: '1px solid #e2e8f0', borderRadius: 12, overflow: 'hidden' }}>
                  <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                    <thead><tr style={{ background: '#f8fafc' }}>
                      {['Associado', 'Condomínio', 'Categoria', 'Status', 'Ações'].map(h => (
                        <th key={h} style={{ padding: '10px 12px', fontSize: 11, fontWeight: 600, textTransform: 'uppercase', color: '#94a3b8', textAlign: 'left' }}>{h}</th>
                      ))}
                    </tr></thead>
                    <tbody>
                      {members
                        .filter(m => !searchTerm || m.full_name?.toLowerCase().includes(searchTerm.toLowerCase()) || m.email?.toLowerCase().includes(searchTerm.toLowerCase()))
                        .slice(0, 20)
                        .map((member) => (
                        <tr key={member.id} style={{ borderBottom: '1px solid #f1f5f9', background: member.status === 'suspended' ? '#fef2f2' : 'transparent' }}>
                          <td style={{ padding: '10px 12px' }}>
                            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                              <div style={{ width: 28, height: 28, borderRadius: '50%', background: member.status === 'suspended' ? '#dc2626' : '#1a5c3a', color: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 10, fontWeight: 700 }}>
                                {member.full_name?.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase()}
                              </div>
                              <div>
                                <div style={{ fontSize: 13, fontWeight: 600 }}>{member.full_name}</div>
                                <div style={{ fontSize: 11, color: '#94a3b8' }}>{member.email}</div>
                              </div>
                            </div>
                          </td>
                          <td style={{ padding: '10px 12px', fontSize: 13 }}>{member.company}</td>
                          <td style={{ padding: '10px 12px' }}>
                            <span style={{ padding: '2px 8px', borderRadius: 12, fontSize: 11, fontWeight: 600, background: member.syndic_categories?.name?.includes('III') ? '#dbeafe' : '#f3f4f6', color: member.syndic_categories?.name?.includes('III') ? '#1e40af' : '#4b5563' }}>
                              {member.syndic_categories?.name || 'Síndico'}
                            </span>
                          </td>
                          <td style={{ padding: '10px 12px' }}>
                            <span style={{ padding: '2px 8px', borderRadius: 12, fontSize: 11, fontWeight: 600, background: member.status === 'active' ? '#dcfce7' : member.status === 'suspended' ? '#fee2e2' : '#f3f4f6', color: member.status === 'active' ? '#166534' : member.status === 'suspended' ? '#991b1b' : '#4b5563' }}>
                              {member.status === 'active' ? 'Ativo' : member.status === 'suspended' ? 'Bloqueado' : 'Inativo'}
                            </span>
                          </td>
                          <td style={{ padding: '10px 12px' }}>
                            <div style={{ display: 'flex', gap: 4 }}>
                              <button onClick={() => { setSelectedMember(member); setShowModal('editMember') }} style={{ padding: '4px 10px', fontSize: 11, fontWeight: 600, borderRadius: 5, border: 'none', cursor: 'pointer', background: '#dbeafe', color: '#1e40af' }}>✏️ Editar</button>
                              {member.status === 'suspended' && (
                                <button onClick={() => unlockAccount(member.id)} style={{ padding: '4px 10px', fontSize: 11, fontWeight: 600, borderRadius: 5, border: 'none', cursor: 'pointer', background: '#dcfce7', color: '#166534' }}>🔓 Desbloquear</button>
                              )}
                              <button onClick={() => { setSelectedMember(member); setShowModal('resetPassword') }} style={{ padding: '4px 10px', fontSize: 11, fontWeight: 600, borderRadius: 5, border: 'none', cursor: 'pointer', background: '#fef3c7', color: '#b45309' }}>🔑 Resetar</button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* SECURITY */}
            {activeTab === 'security' && (
              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
                  <div>
                    <h1 style={{ fontSize: 18, fontWeight: 700 }}>🔒 Configurações de Segurança</h1>
                    <p style={{ fontSize: 12, color: '#94a3b8' }}>Parametrize tentativas de login, bloqueios e políticas de senha</p>
                  </div>
                  <button onClick={() => { Object.entries(settings).forEach(([k, s]) => updateSetting(k, s.setting_value)) }} style={{ padding: '6px 16px', background: 'linear-gradient(135deg, #2d8f5a, #1a5c3a)', color: 'white', border: 'none', borderRadius: 6, fontSize: 12, fontWeight: 600, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6 }}>
                    <Save size={14} /> Salvar
                  </button>
                </div>

                <div style={{ background: '#fef3c7', border: '1px solid #f59e0b', borderRadius: 8, padding: '10px 14px', marginBottom: 16, display: 'flex', alignItems: 'center', gap: 10 }}>
                  <AlertTriangle size={18} style={{ color: '#92400e' }} />
                  <div style={{ fontSize: 13, color: '#92400e' }}>
                    <strong>{members.filter(m => m.status === 'suspended').length} contas bloqueadas</strong> no momento.
                  </div>
                </div>

                <div style={{ background: '#fff', border: '1px solid #e2e8f0', borderRadius: 10, padding: 16, marginBottom: 12 }}>
                  <h3 style={{ fontSize: 14, fontWeight: 700, marginBottom: 10 }}>🚫 Bloqueio por Tentativas</h3>
                  {[
                    { key: 'max_login_attempts', label: 'Máximo de tentativas incorretas', unit: 'tentativas', default: 5 },
                    { key: 'lockout_duration_minutes', label: 'Intervalo de tempo', unit: 'minutos', default: 5 },
                    { key: 'lockout_duration_minutes', label: 'Duração do bloqueio', unit: 'minutos', default: 5 },
                  ].map((field) => (
                    <div key={field.label} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '6px 0', borderBottom: '1px solid #f1f5f9' }}>
                      <span style={{ fontSize: 13 }}>{field.label}</span>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                        <span style={{ fontSize: 12, color: '#94a3b8' }}>{field.unit}</span>
                        <input type="number" value={settings[field.key]?.setting_value || field.default}
                          onChange={(e) => setSettings({ ...settings, [field.key]: { ...settings[field.key], setting_value: e.target.value } })}
                          style={{ width: 60, padding: '4px 8px', border: '1px solid #e2e8f0', borderRadius: 6, fontSize: 13, textAlign: 'center' }} />
                      </div>
                    </div>
                  ))}
                  <div style={{ marginTop: 12, padding: 10, background: '#f8fafc', borderRadius: 8, fontSize: 12, color: '#64748b' }}>
                    <strong>Pré-visualização:</strong> Se um associado errar a senha <strong>{settings['max_login_attempts']?.setting_value || 5} vezes</strong> em <strong>{settings['lockout_duration_minutes']?.setting_value || 5} minutos</strong>, a conta será bloqueada por <strong>{settings['lockout_duration_minutes']?.setting_value || 5} minutos</strong>.
                  </div>
                </div>

                <div style={{ background: '#fff', border: '1px solid #e2e8f0', borderRadius: 10, padding: 16, marginBottom: 12 }}>
                  <h3 style={{ fontSize: 14, fontWeight: 700, marginBottom: 10 }}>👤 Permissões de Manager</h3>
                  {[
                    { key: 'allow_manager_reset_password', label: 'Manager pode resetar senhas' },
                    { key: 'allow_manager_unlock', label: 'Manager pode desbloquear contas' },
                    { key: 'notify_on_password_reset', label: 'Notificar associado no reset' },
                  ].map((toggle) => (
                    <div key={toggle.key} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '6px 0', borderBottom: '1px solid #f1f5f9' }}>
                      <span style={{ fontSize: 13 }}>{toggle.label}</span>
                      <div onClick={() => updateSetting(toggle.key, settings[toggle.key]?.setting_value === 'true' ? 'false' : 'true')}
                        style={{ width: 36, height: 20, borderRadius: 10, background: settings[toggle.key]?.setting_value === 'true' ? '#2d8f5a' : '#e2e8f0', position: 'relative', cursor: 'pointer' }}>
                        <div style={{ width: 16, height: 16, borderRadius: '50%', background: 'white', position: 'absolute', top: 2, left: settings[toggle.key]?.setting_value === 'true' ? 18 : 2, transition: 'left 0.2s' }} />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </>
        )}
      </main>

      {/* Modais */}
      {showModal && (
        <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, background: 'rgba(0,0,0,0.4)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 100 }} onClick={() => setShowModal(null)}>
          <div style={{ background: '#fff', borderRadius: 12, padding: 24, width: '90%', maxWidth: 420, boxShadow: '0 20px 60px rgba(0,0,0,0.15)' }} onClick={(e) => e.stopPropagation()}>

            {showModal === 'resetPassword' && (
              <>
                <h3 style={{ fontSize: 16, fontWeight: 700, marginBottom: 12 }}>🔑 Resetar Senha</h3>
                <p style={{ fontSize: 13, color: '#64748b', marginBottom: 16 }}>Gerar senha temporária para <strong>{selectedMember?.full_name}</strong>?</p>
                <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
                  <button onClick={() => setShowModal(null)} style={{ padding: '8px 16px', borderRadius: 8, fontSize: 13, fontWeight: 600, border: 'none', cursor: 'pointer', background: '#f1f5f9', color: '#64748b' }}>Cancelar</button>
                  <button onClick={() => generatePassword(selectedMember.id)} style={{ padding: '8px 16px', borderRadius: 8, fontSize: 13, fontWeight: 600, border: 'none', cursor: 'pointer', background: 'linear-gradient(135deg, #2d8f5a, #1a5c3a)', color: 'white' }}>Gerar Senha</button>
                </div>
              </>
            )}

            {showModal === 'showPassword' && (
              <>
                <h3 style={{ fontSize: 16, fontWeight: 700, marginBottom: 12 }}>✅ Senha Gerada</h3>
                <div style={{ background: '#1a5c3a', color: 'white', padding: 16, borderRadius: 10, textAlign: 'center', margin: '12px 0' }}>
                  <div style={{ fontSize: 24, fontWeight: 700, fontFamily: 'monospace', letterSpacing: 2 }}>{tempPassword}</div>
                  <div style={{ fontSize: 11, opacity: 0.8, marginTop: 6 }}>Válida por 24h · Copie agora</div>
                </div>
                <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
                  <button onClick={() => { navigator.clipboard.writeText(tempPassword); toast.success('Copiado!') }} style={{ padding: '8px 16px', borderRadius: 8, fontSize: 13, fontWeight: 600, border: 'none', cursor: 'pointer', background: 'linear-gradient(135deg, #2d8f5a, #1a5c3a)', color: 'white' }}>📋 Copiar</button>
                  <button onClick={() => setShowModal(null)} style={{ padding: '8px 16px', borderRadius: 8, fontSize: 13, fontWeight: 600, border: 'none', cursor: 'pointer', background: '#f1f5f9', color: '#64748b' }}>Fechar</button>
                </div>
              </>
            )}

            {showModal === 'reject' && (
              <>
                <h3 style={{ fontSize: 16, fontWeight: 700, marginBottom: 12 }}>✕ Rejeitar Atividade</h3>
                <label style={{ fontSize: 12, fontWeight: 600, color: '#64748b', display: 'block', marginBottom: 4 }}>Motivo (obrigatório)</label>
                <textarea id="rejectReason" placeholder="Ex: Nota fiscal não é de parceiro..." rows={3} style={{ width: '100%', padding: '8px 12px', border: '1px solid #e2e8f0', borderRadius: 8, fontSize: 13, resize: 'vertical', marginBottom: 16 }} />
                <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
                  <button onClick={() => setShowModal(null)} style={{ padding: '8px 16px', borderRadius: 8, fontSize: 13, fontWeight: 600, border: 'none', cursor: 'pointer', background: '#f1f5f9', color: '#64748b' }}>Cancelar</button>
                  <button onClick={() => { const r = document.getElementById('rejectReason').value; if (!r) { toast.error('Informe o motivo'); return } rejectActivity(selectedMember.id, r); setShowModal(null); }} style={{ padding: '8px 16px', borderRadius: 8, fontSize: 13, fontWeight: 600, border: 'none', cursor: 'pointer', background: '#dc2626', color: 'white' }}>Rejeitar</button>
                </div>
              </>
            )}

            {showModal === 'editMember' && (
              <>
                <h3 style={{ fontSize: 16, fontWeight: 700, marginBottom: 12 }}>✏️ Editar Associado</h3>
                <div style={{ display: 'grid', gap: 10, marginBottom: 16 }}>
                  <div><label style={{ fontSize: 11, fontWeight: 600, color: '#64748b', display: 'block', marginBottom: 3 }}>Nome</label><input type="text" defaultValue={selectedMember?.full_name} style={{ width: '100%', padding: '6px 10px', border: '1px solid #e2e8f0', borderRadius: 6, fontSize: 13 }} /></div>
                  <div><label style={{ fontSize: 11, fontWeight: 600, color: '#64748b', display: 'block', marginBottom: 3 }}>E-mail</label><input type="email" defaultValue={selectedMember?.email} style={{ width: '100%', padding: '6px 10px', border: '1px solid #e2e8f0', borderRadius: 6, fontSize: 13 }} /></div>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
                    <div><label style={{ fontSize: 11, fontWeight: 600, color: '#64748b', display: 'block', marginBottom: 3 }}>Categoria</label><select style={{ width: '100%', padding: '6px 10px', border: '1px solid #e2e8f0', borderRadius: 6, fontSize: 13 }}><option>Síndico I</option><option>Síndico II</option><option>Síndico III</option></select></div>
                    <div><label style={{ fontSize: 11, fontWeight: 600, color: '#64748b', display: 'block', marginBottom: 3 }}>Status</label><select defaultValue={selectedMember?.status} style={{ width: '100%', padding: '6px 10px', border: '1px solid #e2e8f0', borderRadius: 6, fontSize: 13 }}><option value="active">Ativo</option><option value="suspended">Bloqueado</option><option value="inactive">Inativo</option></select></div>
                  </div>
                </div>
                <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
                  <button onClick={() => setShowModal(null)} style={{ padding: '8px 16px', borderRadius: 8, fontSize: 13, fontWeight: 600, border: 'none', cursor: 'pointer', background: '#f1f5f9', color: '#64748b' }}>Cancelar</button>
                  <button onClick={() => { toast.success('Associado atualizado!'); setShowModal(null); }} style={{ padding: '8px 16px', borderRadius: 8, fontSize: 13, fontWeight: 600, border: 'none', cursor: 'pointer', background: 'linear-gradient(135deg, #2d8f5a, #1a5c3a)', color: 'white' }}>Salvar</button>
                </div>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  )
}
