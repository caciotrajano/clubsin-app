import { useAuth } from '../hooks/useAuth'
import Sidebar from './Sidebar'
import { useRouter } from 'next/router'
import { useEffect } from 'react'

export default function Layout({ children }) {
  const { user, loading, profile } = useAuth()
  const router = useRouter()
  const isLoginPage = router.pathname === '/login'

  useEffect(() => {
    if (!loading && !user && !isLoginPage) {
      router.push('/login')
    }
  }, [user, loading, isLoginPage, router])

  if (loading) {
    return (
      <div style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        height: '100vh',
        background: '#f8fafc'
      }}>
        <div style={{ textAlign: 'center' }}>
          <div style={{
            width: 40, height: 40,
            border: '3px solid #e8f5ee',
            borderTop: '3px solid #1a5c3a',
            borderRadius: '50%',
            animation: 'spin 1s linear infinite',
            margin: '0 auto 16px'
          }} />
          <p style={{ color: '#64748b', fontSize: 14 }}>Carregando...</p>
        </div>
        <style>{`@keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }`}</style>
      </div>
    )
  }

  if (isLoginPage) {
    return <>{children}</>
  }

  return (
    <div style={{ display: 'flex', minHeight: '100vh', background: '#f8fafc' }}>
      <Sidebar profile={profile} />
      <main style={{ flex: 1, padding: '24px 32px', overflow: 'auto' }}>
        {children}
      </main>
    </div>
  )
}
