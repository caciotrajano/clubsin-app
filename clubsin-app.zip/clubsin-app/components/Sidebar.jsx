import Link from 'next/link'
import { useRouter } from 'next/router'
import { useAuth } from '../hooks/useAuth'
import {
  LayoutDashboard,
  Trophy,
  PlusCircle,
  User,
  Settings,
  LogOut,
  Shield,
  Users
} from 'lucide-react'

export default function Sidebar({ profile }) {
  const router = useRouter()
  const { signOut, isAdmin, isManager } = useAuth()

  const menuItems = [
    { href: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { href: '/atividades', label: 'Atividades', icon: PlusCircle },
    { href: '/perfil', label: 'Meu Perfil', icon: User },
  ]

  // Só mostra menu admin para admin/manager
  if (isAdmin || isManager) {
    menuItems.push({ href: '/admin', label: 'Administração', icon: Shield })
  }

  const isActive = (path) => router.pathname === path || router.pathname.startsWith(path + '/')

  return (
    <aside style={{
      width: 240,
      background: '#fff',
      borderRight: '1px solid #e2e8f0',
      display: 'flex',
      flexDirection: 'column',
      padding: '20px 0'
    }}>
      {/* Logo */}
      <div style={{ padding: '0 20px 20px', borderBottom: '1px solid #e2e8f0', marginBottom: 16 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{
            width: 36, height: 36,
            background: 'linear-gradient(135deg, #2d8f5a, #1a5c3a)',
            borderRadius: 10,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            color: 'white', fontSize: 16, fontWeight: 700
          }}>
            C
          </div>
          <div>
            <div style={{ fontSize: 15, fontWeight: 700, color: '#1e293b' }}>Clubsin Ceará</div>
            <div style={{ fontSize: 11, color: '#94a3b8' }}>Portal do Associado</div>
          </div>
        </div>
      </div>

      {/* Menu */}
      <nav style={{ flex: 1, padding: '0 12px' }}>
        {menuItems.map((item) => {
          const Icon = item.icon
          const active = isActive(item.href)
          return (
            <Link
              key={item.href}
              href={item.href}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 10,
                padding: '10px 14px',
                borderRadius: 8,
                marginBottom: 4,
                fontSize: 14,
                fontWeight: active ? 600 : 500,
                color: active ? '#1a5c3a' : '#64748b',
                background: active ? '#e8f5ee' : 'transparent',
                textDecoration: 'none',
                transition: 'all 0.15s'
              }}
            >
              <Icon size={18} />
              {item.label}
            </Link>
          )
        })}
      </nav>

      {/* User + Logout */}
      <div style={{ padding: '16px 20px 0', borderTop: '1px solid #e2e8f0' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12 }}>
          <div style={{
            width: 32, height: 32,
            borderRadius: '50%',
            background: '#1a5c3a',
            color: 'white',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 12, fontWeight: 700
          }}>
            {profile?.full_name?.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase() || '?'}
          </div>
          <div style={{ overflow: 'hidden' }}>
            <div style={{ fontSize: 13, fontWeight: 600, color: '#1e293b', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
              {profile?.full_name || 'Carregando...'}
            </div>
            <div style={{ fontSize: 11, color: '#94a3b8' }}>
              {isAdmin ? 'Administrador' : isManager ? 'Manager' : 'Associado'}
            </div>
          </div>
        </div>
        <button
          onClick={() => signOut()}
          style={{
            width: '100%',
            display: 'flex', alignItems: 'center', gap: 8,
            padding: '8px 12px',
            borderRadius: 6,
            border: '1px solid #e2e8f0',
            background: 'transparent',
            color: '#64748b',
            fontSize: 13,
            fontWeight: 500,
            cursor: 'pointer'
          }}
        >
          <LogOut size={16} />
          Sair
        </button>
      </div>
    </aside>
  )
}
