import { useState, useEffect } from 'react'
import { supabase } from '../lib/supabase'

export function useRanking(seasonId = 'season-2026-001') {
  const [rankings, setRankings] = useState([])
  const [myRanking, setMyRanking] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchRankings()
  }, [seasonId])

  async function fetchRankings() {
    setLoading(true)

    // Buscar ranking com dados do perfil
    const { data, error } = await supabase
      .from('rankings')
      .select(`
        *,
        profiles(full_name, avatar_url, company)
      `)
      .eq('season_id', seasonId)
      .order('position', { ascending: true })
      .limit(100)

    if (error) {
      console.error('Erro ao buscar ranking:', error)
      setLoading(false)
      return
    }

    setRankings(data || [])

    // Buscar ranking do usuário logado
    const { data: { user } } = await supabase.auth.getUser()
    if (user) {
      const myRank = data?.find(r => r.profile_id === user.id)
      setMyRanking(myRank)
    }

    setLoading(false)
  }

  return { rankings, myRanking, loading, refetch: fetchRankings }
}
